-- s92064060
-- 721424060


create database ABCBank;
use ABCBank;

-- create table branch and insert data
-- s92064060
-- 721424060

CREATE TABLE branch (
  branchNo INT PRIMARY KEY,
  city VARCHAR(50) NOT NULL,
  branchContactNo VARCHAR(20) NOT NULL
);

INSERT INTO branch (branchNo, city, branchContactNo)
VALUES 
('001', 'colombo', '0119898112'),
('002', 'kandy', '0732368198'),
('003', 'galle', '0783222456'),
('004', 'ampara', '0632248178');

-- -- create table customer and insert data
-- s92064060
-- 721424060


CREATE TABLE customer (
  nic VARCHAR(12) NOT NULL PRIMARY KEY,
  initials VARCHAR(10) NOT NULL,
  surname VARCHAR(50) NOT NULL,
  address VARCHAR(100) NOT NULL,
  dob DATE
);

INSERT INTO customer (nic, initials, surname, address, dob) VALUES 
('982660661', 'M.N.M', 'Safran', '181,main str,Pottuvil', '1998-09-22'),
('981456788', 'K.L', 'Kane', '23,main str,colombo', '1998-02-05'),
('200045618521', 'J', 'Fernando', '45/b,main str,kalmunai', '2000-08-22'),
('199925254545', 'R.M', 'Riswan', '78,main str,Maruthamunai', '1999-05-28');

-- s92064060
-- 721424060
-- create table manager and insert data

CREATE TABLE manager (
  branchNo INT,
  mgrName VARCHAR(50) NOT NULL,
  mgrPhoneNo VARCHAR(20) NOT NULL,
  mgrAddress VARCHAR(100) NOT NULL,
  mgrAppointmentDate DATE,
  FOREIGN KEY (branchNo) REFERENCES branch(branchNo)
);

INSERT INTO manager (branchNo, mgrName, mgrPhoneNo, mgrAddress, mgrAppointmentDate) VALUES 
('001', 'John Smith', '0779898112', '28, main str, pottuvil', '2022-01-01'),
('002', 'Kais looli', '0759898133', '456, main str, kalmunai', '2022-01-01'),
('003', 'ajanda mendis', '07798998648', '234, main str, maruthamunai', '2022-01-01'),
('004', 'sooriya kumar', '0759898456', '145, main str, colombo', '2022-01-01');

-- s92064060
-- 721424060
-- create table bankAccount and insert data

CREATE TABLE bankAccount (
  accountNo INT not null PRIMARY KEY,
  accbalance DECIMAL(10,2),
  accType VARCHAR(20) not null,
  createdDate DATE,
  branchNo INT,
  nic VARCHAR(12) not null,
  FOREIGN KEY (branchNo) REFERENCES branch(branchNo),
  FOREIGN KEY (nic) REFERENCES customer(nic)
);

INSERT INTO bankAccount (accountNo, accbalance, accType, createdDate, branchNo, nic) VALUES 
('783845', 5000.00, 'Savings', '2022-01-01', '001', '982660661'),
('783865', 112000.00, 'Savings', '2022-01-02', '002', '981456788'),
('783812', 68000.00, 'Savings', '2022-01-03', '003', '200045618521'),
('783889', 70000.00, 'Savings', '2022-01-03', '004', '199925254545');

-- s92064060
-- 721424060
-- showing created table

select *from branch;
select *from customer;
select *from manager;
select *from bankAccount;

-- Q03
ALTER TABLE branch ADD COLUMN email VARCHAR(100);

-- Q04
DELETE FROM bankAccount WHERE accType = 'savings';

-- Q05
UPDATE bankAccount 
SET accbalance = accbalance - 100 WHERE accbalance > 50000;

-- Q06
ALTER TABLE manager 
DROP COLUMN mgrPhoneNo;

-- Q07
ALTER TABLE bankAccount 
ADD CONSTRAINT fk_customer_nic
FOREIGN KEY (nic) REFERENCES customer(nic) ON DELETE CASCADE;

-- Q08_1
SELECT *FROM branch
WHERE city = 'colombo';

-- Q08_2
SELECT customer.initials, customer.surname, bankaccount.accountNo, bankaccount.accbalance
FROM bankAccount
JOIN customer ON bankaccount.nic = customer.nic
ORDER BY bankaccount.accbalance DESC;

-- 	Q08_3
SELECT branch.branchNo, branch.city, COUNT(bankaccount.accountNo) AS accountCount
FROM branch
LEFT JOIN bankAccount ON branch.branchNo = bankaccount.branchNo
GROUP BY branch.branchNo, branch.city;

-- Q08_4
SELECT customer.nic, customer.address, bankaccount.createdDate
FROM customer
JOIN bankAccount ON customer.nic = bankaccount.nic
ORDER BY bankaccount.createdDate
LIMIT 2;

-- Q08_5
SELECT manager.mgrName, manager.mgrAppointmentDate, branch.city, branch.branchContactNo
FROM manager
JOIN branch ON manager.branchNo = branch.branchNo
WHERE manager.mgrAppointmentDate > '2022-01-02';

-- Q08_6
SELECT accType, SUM(accbalance) AS totalBalance
FROM bankAccount
GROUP BY accType
HAVING totalBalance > 50000;